var searchData=
[
  ['acceptance_5fof_5fshot',['ACCEPTANCE_OF_SHOT',['../game_stage_8h.html#abf9b1403a2916c71f3d5b4b44f300396a76d8a167a588e86d96d767fb94b3f1a0',1,'gameStage.h']]],
  ['aiming',['AIMING',['../game_stage_8h.html#abf9b1403a2916c71f3d5b4b44f300396a56a12b47e812dfad01ec8a8f78bfd99b',1,'gameStage.h']]]
];
