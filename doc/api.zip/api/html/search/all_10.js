var searchData=
[
  ['waiting_5ffor_5fresponce',['WAITING_FOR_RESPONCE',['../game_stage_8h.html#abf9b1403a2916c71f3d5b4b44f300396a7247ff6a42c9804e6575038c98498929',1,'gameStage.h']]],
  ['waiting_5fopponents_5fsetting',['WAITING_OPPONENTS_SETTING',['../game_stage_8h.html#abf9b1403a2916c71f3d5b4b44f300396adaec876b2398c251ccac721ba650f208',1,'gameStage.h']]]
];
