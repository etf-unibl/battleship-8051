var searchData=
[
  ['shipindex',['shipIndex',['../buttons_8c.html#ac7fa4e440e56e86a1dddc4037084d9fb',1,'shipIndex():&#160;display.c'],['../display_8c.html#ac7fa4e440e56e86a1dddc4037084d9fb',1,'shipIndex():&#160;display.c'],['../_my_project_8c.html#ac7fa4e440e56e86a1dddc4037084d9fb',1,'shipIndex():&#160;display.c']]],
  ['shipsize',['shipSize',['../buttons_8c.html#a2e6b2a801a93dd9d42d4eb4504d0f128',1,'shipSize():&#160;display.c'],['../display_8c.html#a2e6b2a801a93dd9d42d4eb4504d0f128',1,'shipSize():&#160;display.c'],['../_my_project_8c.html#a2e6b2a801a93dd9d42d4eb4504d0f128',1,'shipSize():&#160;display.c']]]
];
