var searchData=
[
  ['matrixsize',['matrixSize',['../display_8c.html#a381482df2bb3ae569835165e26a3b317',1,'display.c']]]
];
