var searchData=
[
  ['readme_2emd',['README.md',['../_r_e_a_d_m_e_8md.html',1,'']]],
  ['resetdiode',['resetDiode',['../display_8h.html#a7d4b9fa149a2567ea23c6313d5bc71fe',1,'display.h']]],
  ['returnship',['returnShip',['../display_8h.html#a5845a08137657dd092aeeb43b9d67ac9',1,'display.h']]]
];
