var searchData=
[
  ['columngreen',['columnGreen',['../display_8c.html#adf82a99599fbf9a1f1a421f189d47cf5',1,'display.c']]],
  ['columnred',['columnRed',['../display_8c.html#a55eb490179c7e8a48147b06751773722',1,'display.c']]]
];
